<?php
/**
 * Page heading template
 */
?>
<div class="wrap">
	<div class="cdi-kit">
